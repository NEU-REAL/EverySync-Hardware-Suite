<div>
<div># EverySync --  An Open Hardware Time Syncronization Sensor Suite</div>
<div>**EverySync** is An Open Hardware Time Syncronization Sensor Suite For Every Casual Sensor In Field Of SLAM.</div>
<div>- Our project provides a complete, open-source hardware, firmware and software bundle to perform `Hardware Time Synchronization ` of multiple sensors in SLAM system.</div>
<br>
<div>Entry of This Project:</div>
<br>
<div>* [EverySync -- HardwareSuite](https://github.com/NEU-REAL/EverySync-Hardware-Suite) Open source Hardware Suite of EverySync.</div>
<div>* [EverySync -- PCB and Examples](https://github.com/NEU-REAL/EverySync-Hardware-Suite/EverySync_PCB) Released. Both Altium Designer and LCEDA versions are provided, make sure the project is easy to reproduce. And we also provide some examples for developers to create their own hardware suites.</div>
<br>
<div>
<div align="center"> </div>
<div><img src="//" align="center"></div>
<div> </div>
</div>
<br><br>
<div>## News</div>
<div>- **May 26, 2022** Finish first version named RealVIS v1.0 .</div>
<div>- **May  8, 2023** Support at least 3 kinds of Lidar.</div>
<div>- **April  2, 2024** Open-source. Submit to IROS2024. Preprint is comming soon.</div>
<div>- **June  30, 2024** Accepted by IROS2024.</div>
<div>- **December 26, 2024** Proceding of IROS2024 is released.</div>
<div>- **January  13, 2025** Project is totally open source. ⭐Happy New Year⭐</div>
</div>            
How to use：

At editor, open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


如何使用：

打开编辑器，通过：顶部菜单 - 文件 - 打开 - 立创EDA... ，选择 json 文件打开在编辑器，你可以保存文档进工程里面。